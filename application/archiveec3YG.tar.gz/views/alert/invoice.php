<article class="content error-404-page">
    <section class="section">
        <div class="error-card">
            <div class="error-title-block">
                <h1 class="error-title">404</h1>
                <h2 class="error-sub-title"> Sorry, page not found </h2>
            </div>
            <div class="error-container">

                <div class="row">

                </div>
                <br> <a class="btn btn-primary" href="<?php echo base_url() ?>"><i class="fa fa-angle-left"></i> Back to
                    Dashboard</a></div>
        </div>
    </section>
</article>