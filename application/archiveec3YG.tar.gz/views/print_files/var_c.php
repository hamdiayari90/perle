$invoice['tid'] {invoice_id}
<?php if (LTR == 'rtl') echo 'margin-left: 200px;' ?>    {LTR}
LTR {LTR_DIRECTION}
<?php echo $this->lang->line('Our Info') ?>  {Text_Our Info}
<?= $general['person'] ?>  {Person_type}
$loc['cname'] {Company_Name}
$loc['address']  {Company_Address}
$loc['city']  {Company_City}
$loc['region'] {Company_Region}
$loc['country'] {Company_Country}
' . $loc['postbox'] . ' {Company_PosBox}
$this->lang->line('Phone')   {Text_Phone}
$loc['phone'] {Company_Phone}
$loc['phone'] {Company_Phone}
$this->lang->line('Email')   {Text_Email}
$loc['email'] {Company_Email}